# Chapter3Notes
 
